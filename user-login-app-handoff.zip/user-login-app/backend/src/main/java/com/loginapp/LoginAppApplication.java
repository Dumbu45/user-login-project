package com.loginapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Entry point — Spring Boot scans this package and all sub-packages
// for @Component, @Service, @Repository, @Controller etc.
@SpringBootApplication
public class LoginAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(LoginAppApplication.class, args);
    }
}

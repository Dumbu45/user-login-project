package com.loginapp.service;

import com.loginapp.dto.*;
import com.loginapp.model.User;
import com.loginapp.repository.UserRepository;
import com.loginapp.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

// =============================================================
// AUTH SERVICE — the business logic layer
//
// The Controller receives HTTP requests.
// The Service contains the actual logic.
// The Repository talks to the database.
//
// Keeping them separate means:
// - Easy to test service logic without HTTP
// - Easy to change DB without touching business rules
// - Clear responsibility for each layer
// =============================================================
@Service
@RequiredArgsConstructor  // Lombok: generates constructor for all final fields
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;  // BCrypt, configured in SecurityConfig
    private final JwtUtil jwtUtil;

    public AuthResponse register(RegisterRequest request) {

        // 1. Check if email already taken
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already registered");
        }

        // 2. Check if username already taken
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new RuntimeException("Username already taken");
        }

        // 3. Create new user — HASH the password before saving
        // BCrypt turns "mypassword" into "$2a$10$randomHashHere..."
        // Even we can't reverse it — that's the point
        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole("USER");

        // 4. Save to database
        userRepository.save(user);

        // 5. Generate JWT token
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole());

        // 6. Return token + user info to frontend
        return new AuthResponse(token, user.getUsername(), user.getEmail(), user.getRole());
    }

    public AuthResponse login(LoginRequest request) {

        // 1. Find user by email — throw error if not found
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid email or password"));

        // 2. Check password using BCrypt
        // passwordEncoder.matches("plain", "hashed") compares safely
        // We NEVER decrypt the stored hash — BCrypt doesn't work that way
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid email or password");
            // Note: same message for wrong email OR wrong password
            // This prevents attackers from knowing which one is wrong
        }

        // 3. Check account is active (not soft-deleted)
        if (!user.getIsActive()) {
            throw new RuntimeException("Account is disabled");
        }

        // 4. Generate JWT and return
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole());
        return new AuthResponse(token, user.getUsername(), user.getEmail(), user.getRole());
    }
}

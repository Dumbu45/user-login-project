package com.loginapp.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.security.Key;
import java.util.Date;

// =============================================================
// JWT UTILITY — creates and validates JSON Web Tokens
//
// HOW JWT WORKS:
// 1. User logs in with correct password
// 2. We create a signed token containing their email + role
// 3. We send the token to the frontend
// 4. Frontend stores token, sends it in every future request
// 5. We verify the token signature — if valid, we trust the user
//
// The token is: header.payload.signature (base64 encoded)
// Example: eyJhbGc... eyJzdWI... xyzSignature
// =============================================================
@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;  // injected from application.properties

    @Value("${jwt.expiration}")
    private long expirationMs; // 86400000 = 24 hours

    // Build the signing key from our secret string
    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(secret.getBytes());
    }

    // Create a JWT token for a user
    public String generateToken(String email, String role) {
        return Jwts.builder()
                .setSubject(email)              // who this token is for
                .claim("role", role)            // extra data inside the token
                .setIssuedAt(new Date())        // when it was created
                .setExpiration(new Date(System.currentTimeMillis() + expirationMs))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256) // sign it
                .compact();
    }

    // Extract the email from a token
    public String extractEmail(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    // Check if a token is valid (not expired, not tampered)
    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            return false; // expired or invalid
        }
    }
}

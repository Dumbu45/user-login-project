package com.loginapp.repository;

import com.loginapp.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

// =============================================================
// REPOSITORY = the layer that talks to the database
// JpaRepository<User, Long> gives us save(), findById(),
// findAll(), delete() etc. FOR FREE — no SQL needed for basics.
// We only write methods for custom queries.
// =============================================================
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Spring Data JPA reads the method name and builds the SQL:
    // SELECT * FROM users WHERE email = ? LIMIT 1
    Optional<User> findByEmail(String email);

    // SELECT * FROM users WHERE username = ? LIMIT 1
    Optional<User> findByUsername(String username);

    // SELECT COUNT(*) > 0 FROM users WHERE email = ?
    boolean existsByEmail(String email);

    // SELECT COUNT(*) > 0 FROM users WHERE username = ?
    boolean existsByUsername(String username);
}

package com.loginapp.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

// =============================================================
// DTO = Data Transfer Object
// This is what the frontend sends when the user clicks Login.
// We use a separate class (not User) so we don't expose
// internal fields like id, role, createdAt to the outside world.
// =============================================================
@Data
public class LoginRequest {
    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Password is required")
    private String password;
}

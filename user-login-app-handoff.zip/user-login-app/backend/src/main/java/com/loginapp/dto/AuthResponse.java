package com.loginapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

// What we send BACK to the frontend after successful login/register
@Data
@AllArgsConstructor
public class AuthResponse {
    private String token;    // JWT token — frontend stores this in localStorage
    private String username;
    private String email;
    private String role;
}

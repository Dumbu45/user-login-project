package com.loginapp.controller;

import com.loginapp.dto.*;
import com.loginapp.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

// =============================================================
// AUTH CONTROLLER — receives HTTP requests from the frontend
//
// @RestController = this class handles HTTP requests
// @RequestMapping = all endpoints here start with /api/auth
// @CrossOrigin    = allow the React frontend to call us
//                   (DevOps sets the actual URL via env var)
//
// ENDPOINTS THIS CONTROLLER EXPOSES:
//   POST /api/auth/register  ← frontend sends username+email+password
//   POST /api/auth/login     ← frontend sends email+password
//   GET  /api/auth/health    ← DevOps uses this to check if app is up
// =============================================================
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@CrossOrigin(origins = "${frontend.url}")
public class AuthController {

    private final AuthService authService;

    // REGISTER endpoint
    // @Valid triggers the validation annotations on RegisterRequest
    // If validation fails, Spring returns 400 automatically
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        try {
            AuthResponse response = authService.register(request);
            return ResponseEntity.ok(response);           // 200 OK + token
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();   // 400 if email taken etc.
        }
    }

    // LOGIN endpoint
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        try {
            AuthResponse response = authService.login(request);
            return ResponseEntity.ok(response);           // 200 OK + token
        } catch (RuntimeException e) {
            return ResponseEntity.status(401).build();    // 401 Unauthorized
        }
    }

    // HEALTH CHECK — DevOps uses this in docker-compose healthcheck
    // If this returns 200, the container is "healthy"
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Backend is running");
    }
}

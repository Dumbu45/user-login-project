package com.loginapp.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

// =============================================================
// SECURITY CONFIG — tells Spring Security what to protect
//
// By default Spring Security locks down EVERYTHING.
// We need to say: auth endpoints are PUBLIC (no token needed)
// Everything else requires a valid JWT token.
// =============================================================
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // Disable CSRF — not needed for stateless JWT APIs
            .csrf(csrf -> csrf.disable())

            // Define which endpoints need authentication
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/**").permitAll() // login, register = open
                .anyRequest().authenticated()               // everything else = needs token
            )

            // Use stateless sessions — JWT means no server-side sessions
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            );

        return http.build();
    }

    // BCrypt password encoder — this is the industry standard
    // BCrypt adds a random "salt" to each password before hashing
    // So even if two users have the same password, the hashes differ
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}

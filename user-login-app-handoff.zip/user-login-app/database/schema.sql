-- =============================================================
-- TIER 3: DATABASE SCHEMA
-- This file creates the users table.
-- PostgreSQL will run this automatically when the container
-- starts for the first time.
-- =============================================================

-- Create the database (if running manually)
-- The Docker container handles this via env vars

CREATE TABLE IF NOT EXISTS users (
    id          BIGSERIAL PRIMARY KEY,         -- auto-incrementing unique ID
    username    VARCHAR(50)  NOT NULL UNIQUE,  -- login name, must be unique
    email       VARCHAR(100) NOT NULL UNIQUE,  -- email, must be unique
    password    VARCHAR(255) NOT NULL,         -- BCrypt hashed password (never plain text)
    role        VARCHAR(20)  NOT NULL DEFAULT 'USER',  -- USER or ADMIN
    created_at  TIMESTAMP    NOT NULL DEFAULT NOW(),   -- when they registered
    is_active   BOOLEAN      NOT NULL DEFAULT TRUE     -- soft delete flag
);

-- Index on email for fast login lookups
CREATE INDEX IF NOT EXISTS idx_users_email    ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);

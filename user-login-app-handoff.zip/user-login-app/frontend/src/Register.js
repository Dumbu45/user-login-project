import React, { useState } from 'react';
import { register } from './api';

// =============================================================
// REGISTER COMPONENT
// User fills in username, email, password and submits.
// We call POST /api/auth/register on the backend.
// On success: store the JWT token and redirect to dashboard.
// =============================================================
function Register({ onSwitchToLogin }) {
  const [form, setForm]     = useState({ username: '', email: '', password: '' });
  const [error, setError]   = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const response = await register(form);
      // Store JWT token — future requests will include it automatically
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify({
        username: response.data.username,
        email: response.data.email,
        role: response.data.role,
      }));
      window.location.href = '/dashboard';
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.card}>
      <h2>Create Account</h2>
      {error && <p style={styles.error}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <input style={styles.input} name="username" placeholder="Username"
               value={form.username} onChange={handleChange} required />
        <input style={styles.input} name="email" type="email" placeholder="Email"
               value={form.email} onChange={handleChange} required />
        <input style={styles.input} name="password" type="password" placeholder="Password (min 8 chars)"
               value={form.password} onChange={handleChange} required />
        <button style={styles.button} type="submit" disabled={loading}>
          {loading ? 'Creating account...' : 'Register'}
        </button>
      </form>
      <p>Already have an account? <button style={styles.link} onClick={onSwitchToLogin}>Login</button></p>
    </div>
  );
}

const styles = {
  card:   { maxWidth: 400, margin: '80px auto', padding: 32, borderRadius: 12, boxShadow: '0 2px 16px #0002', fontFamily: 'sans-serif' },
  input:  { display: 'block', width: '100%', marginBottom: 12, padding: '10px 14px', borderRadius: 6, border: '1px solid #ddd', fontSize: 15, boxSizing: 'border-box' },
  button: { width: '100%', padding: '12px 0', background: '#2563eb', color: '#fff', border: 'none', borderRadius: 6, fontSize: 16, cursor: 'pointer' },
  error:  { color: '#dc2626', marginBottom: 12 },
  link:   { background: 'none', border: 'none', color: '#2563eb', cursor: 'pointer', padding: 0 },
};

export default Register;

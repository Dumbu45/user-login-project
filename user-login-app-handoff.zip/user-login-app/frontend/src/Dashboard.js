import React from 'react';

// Protected page — only reachable after successful login
function Dashboard() {
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/';
  };

  return (
    <div style={{ maxWidth: 600, margin: '80px auto', padding: 32, fontFamily: 'sans-serif' }}>
      <h2>Dashboard</h2>
      <p>Welcome, <strong>{user.username}</strong>!</p>
      <p>Email: {user.email}</p>
      <p>Role: {user.role}</p>
      <button onClick={logout} style={{ padding: '10px 24px', background: '#dc2626', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer' }}>
        Logout
      </button>
    </div>
  );
}

export default Dashboard;

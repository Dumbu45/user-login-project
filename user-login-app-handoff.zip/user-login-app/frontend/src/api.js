// =============================================================
// API LAYER — all HTTP calls to the backend live here
//
// Using axios (like fetch but with better error handling).
// REACT_APP_API_URL comes from the environment variable
// DevOps sets this in docker-compose or .env
// If not set, falls back to /api (works with nginx proxy)
// =============================================================
import axios from 'axios';

const API = axios.create({
  baseURL: process.env.REACT_APP_API_URL || '/api',
});

// Attach JWT token to every request automatically
// So we don't have to do it manually in every component
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const register = (data) => API.post('/auth/register', data);
export const login    = (data) => API.post('/auth/login', data);

import React, { useState } from 'react';
import { login } from './api';

function Login({ onSwitchToRegister }) {
  const [form, setForm]     = useState({ email: '', password: '' });
  const [error, setError]   = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const response = await login(form);
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('user', JSON.stringify({
        username: response.data.username,
        email: response.data.email,
        role: response.data.role,
      }));
      window.location.href = '/dashboard';
    } catch (err) {
      setError('Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.card}>
      <h2>Welcome Back</h2>
      {error && <p style={styles.error}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <input style={styles.input} name="email" type="email" placeholder="Email"
               value={form.email} onChange={handleChange} required />
        <input style={styles.input} name="password" type="password" placeholder="Password"
               value={form.password} onChange={handleChange} required />
        <button style={styles.button} type="submit" disabled={loading}>
          {loading ? 'Logging in...' : 'Login'}
        </button>
      </form>
      <p>No account? <button style={styles.link} onClick={onSwitchToRegister}>Register</button></p>
    </div>
  );
}

const styles = {
  card:   { maxWidth: 400, margin: '80px auto', padding: 32, borderRadius: 12, boxShadow: '0 2px 16px #0002', fontFamily: 'sans-serif' },
  input:  { display: 'block', width: '100%', marginBottom: 12, padding: '10px 14px', borderRadius: 6, border: '1px solid #ddd', fontSize: 15, boxSizing: 'border-box' },
  button: { width: '100%', padding: '12px 0', background: '#2563eb', color: '#fff', border: 'none', borderRadius: 6, fontSize: 16, cursor: 'pointer' },
  error:  { color: '#dc2626', marginBottom: 12 },
  link:   { background: 'none', border: 'none', color: '#2563eb', cursor: 'pointer', padding: 0 },
};

export default Login;

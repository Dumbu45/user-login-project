import React, { useState } from 'react';
import Login from './Login';
import Register from './Register';
import Dashboard from './Dashboard';

function App() {
  const [page, setPage] = useState('login');
  const token = localStorage.getItem('token');

  // If user already has a token, show dashboard
  if (token && window.location.pathname === '/dashboard') {
    return <Dashboard />;
  }

  if (page === 'register') {
    return <Register onSwitchToLogin={() => setPage('login')} />;
  }
  return <Login onSwitchToRegister={() => setPage('register')} />;
}

export default App;

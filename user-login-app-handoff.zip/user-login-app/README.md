# User Login App — Developer Handoff

## Architecture
- **Frontend**: React (port 3000)
- **Backend**: Spring Boot Java (port 8080)
- **Database**: PostgreSQL (port 5432)

## For DevOps — What You Need to Do

### 1. Write 3 Dockerfiles (one per tier)

**backend/Dockerfile** — multi-stage build:
```
Stage 1 (builder): Use maven:3.9-openjdk-17 image, run: mvn clean package -DskipTests
Stage 2 (runtime): Use openjdk:17-jre-slim, copy JAR from stage 1, EXPOSE 8080, CMD java -jar app.jar
```

**frontend/Dockerfile** — multi-stage build:
```
Stage 1 (builder): Use node:18-alpine, run: npm install && npm run build
Stage 2 (runtime): Use nginx:alpine, copy build/ folder to /usr/share/nginx/html
```

**database/** — No Dockerfile needed. Use the official postgres:15 image directly.
Mount schema.sql to /docker-entrypoint-initdb.d/ and it auto-runs on first start.

### 2. Write docker-compose.yml
Three services: postgres, backend, frontend
- postgres starts first (backend depends_on postgres)
- backend starts second (frontend depends_on backend)
- Use healthchecks on backend: GET /api/auth/health → 200

### 3. Environment Variables to Set
See .env.example — copy to .env and fill in values.
Key ones:
- DB_HOST=postgres (matches docker-compose service name)
- JWT_SECRET=<random 64-char string>
- DB_PASSWORD=<strong password>

### 4. Ports
| Service  | Container Port | Host Port |
|----------|---------------|-----------|
| Frontend | 80 (nginx)    | 3000      |
| Backend  | 8080          | 8080      |
| Database | 5432          | 5432      |

### 5. Health Check Endpoints
- Backend: GET http://localhost:8080/api/auth/health → "Backend is running"

## API Contract

### POST /api/auth/register
Request body:
```json
{ "username": "john", "email": "john@example.com", "password": "mypassword123" }
```
Response 200:
```json
{ "token": "eyJ...", "username": "john", "email": "john@example.com", "role": "USER" }
```

### POST /api/auth/login
Request body:
```json
{ "email": "john@example.com", "password": "mypassword123" }
```
Response 200: same as register
Response 401: wrong credentials

## Build Commands (for reference)
```bash
# Backend: produces target/user-login-app-1.0.0.jar
cd backend && mvn clean package -DskipTests

# Frontend: produces build/ folder
cd frontend && npm install && npm run build
```
